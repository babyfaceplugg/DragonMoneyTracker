// ============================================================
// Dragon Tracker — content.js (v3.0, sad & happy edition)
// ============================================================
(function () {
    'use strict';

    const host = location.hostname;
    if (!host.includes('drgn') && !host.includes('dragon')) {
        console.log("🔥 Dragon Tracker: не наш домен.");
        return;
    }
    console.log("🔥 Dragon Tracker: скрипт загружен");

    const DELAY_AFTER_RENDER = 200;
    const DELAY_BETWEEN_CLICKS = 150;
    const PAGE_LOAD_TIMEOUT = 6000;
    const SCRAPE_DEBOUNCE = 400;
    const EFFECT_COOLDOWN = 1500;

    let isAutoRunning = false;
    let observer = null;
    let lastEffectTime = 0;

    const statData = { deposits: 0, withdrawals: 0, processedIds: [] };

    const isHistoryPage = () => location.pathname.includes('/wallet/history');
    const getNextButton = () => document.querySelector('button[name="arrow-right2"]');

    function getCurrentPageNumber() {
        const wrap = document.querySelector('.mt-4');
        if (!wrap) return null;
        const btn = wrap.querySelector('button.select');
        return btn ? btn.innerText.trim() : null;
    }

    function getDataRowIds() {
        const ids = [];
        document.querySelectorAll('.flex.row').forEach(r => {
            if (r.querySelector('.head')) return;
            const c = r.querySelector('.cell');
            if (c) {
                const id = c.innerText.replace(/\D/g, '');
                if (id) ids.push(id);
            }
        });
        return ids;
    }

    function hasNoData() {
        const body = document.querySelector('.relative.min-h-\\[56px\\]') || document.body;
        if (body.innerText && body.innerText.toLowerCase().includes('нет данных')) return true;
        let cnt = 0;
        body.querySelectorAll('.flex.row').forEach(r => {
            if (!r.querySelector('.head')) cnt++;
        });
        return cnt === 0;
    }

    function setStatus(text) {
        const el = document.getElementById('dt-status');
        if (el) el.textContent = text;
    }

    // ========== АУДИО ==========
    function initAudio() {
        try {
            if (!window._dtAudioCtx) {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (AudioCtx) window._dtAudioCtx = new AudioCtx();
            }
            if (window._dtAudioCtx && window._dtAudioCtx.state === 'suspended') {
                window._dtAudioCtx.resume();
            }
        } catch (e) {
            console.warn('🔥 Audio init error:', e);
        }
    }

    // Весёлая фанфара (C → E → G → аккорд + искры)
    function playFanfare() {
        try {
            const ctx = window._dtAudioCtx;
            if (!ctx) return;
            if (ctx.state === 'suspended') ctx.resume();

            const now = ctx.currentTime;

            const melody = [
                { freq: 523.25, start: 0.00, dur: 0.16 },  // C5
                { freq: 659.25, start: 0.16, dur: 0.16 },  // E5
                { freq: 783.99, start: 0.32, dur: 0.16 },  // G5
            ];
            const chord = [
                { freq: 1046.50 },
                { freq: 1318.51 },
                { freq: 1567.98 },
            ];

            melody.forEach(n => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.value = n.freq;
                gain.gain.setValueAtTime(0, now + n.start);
                gain.gain.linearRampToValueAtTime(0.10, now + n.start + 0.02);
                gain.gain.exponentialRampToValueAtTime(0.001, now + n.start + n.dur);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now + n.start);
                osc.stop(now + n.start + n.dur + 0.05);
            });

            chord.forEach(n => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.value = n.freq;
                const startAt = now + 0.48;
                gain.gain.setValueAtTime(0, startAt);
                gain.gain.linearRampToValueAtTime(0.07, startAt + 0.03);
                gain.gain.exponentialRampToValueAtTime(0.001, startAt + 0.9);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(startAt);
                osc.stop(startAt + 1.0);
            });

            for (let i = 0; i < 6; i++) {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sine';
                osc.frequency.value = 2000 + Math.random() * 2000;
                const t = now + 0.5 + i * 0.08;
                gain.gain.setValueAtTime(0.04, t);
                gain.gain.exponentialRampToValueAtTime(0.001, t + 0.15);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(t);
                osc.stop(t + 0.2);
            }
        } catch (e) {
            console.warn('🔥 Fanfare error:', e);
        }
    }

    // Грустный тромбон (Bb → A → Ab → G с вибрато)
    function playSadSound() {
        try {
            const ctx = window._dtAudioCtx;
            if (!ctx) return;
            if (ctx.state === 'suspended') ctx.resume();

            const now = ctx.currentTime;

            const notes = [
                { freq: 233.08, start: 0.00, dur: 0.35 },  // Bb3
                { freq: 220.00, start: 0.35, dur: 0.35 },  // A3
                { freq: 207.65, start: 0.70, dur: 0.35 },  // Ab3
                { freq: 196.00, start: 1.05, dur: 1.30 },  // G3 (long, with vibrato)
            ];

            notes.forEach(n => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(n.freq, now + n.start);

                // Небольшой "съезд" вниз для "wah" эффекта
                if (n.dur > 1) {
                    osc.frequency.linearRampToValueAtTime(n.freq * 0.88, now + n.start + n.dur);
                } else {
                    osc.frequency.linearRampToValueAtTime(n.freq * 0.96, now + n.start + n.dur);
                }

                // Вибрато на последней длинной ноте
                if (n.dur > 1) {
                    const lfo = ctx.createOscillator();
                    const lfoGain = ctx.createGain();
                    lfo.frequency.value = 5.5;
                    lfoGain.gain.value = 7;
                    lfo.connect(lfoGain);
                    lfoGain.connect(osc.frequency);
                    lfo.start(now + n.start);
                    lfo.stop(now + n.start + n.dur);
                }

                gain.gain.setValueAtTime(0, now + n.start);
                gain.gain.linearRampToValueAtTime(0.11, now + n.start + 0.03);
                gain.gain.setValueAtTime(0.11, now + n.start + n.dur - 0.15);
                gain.gain.exponentialRampToValueAtTime(0.001, now + n.start + n.dur);

                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(now + n.start);
                osc.stop(now + n.start + n.dur + 0.05);
            });
        } catch (e) {
            console.warn('🔥 Sad sound error:', e);
        }
    }

    // ========== СТИЛИ ==========
    function injectStyles() {
        if (document.getElementById('dt-styles')) return;
        const s = document.createElement('style');
        s.id = 'dt-styles';
        s.textContent = `
            #dragon-tracker-panel {
                position: fixed; top: 16px; right: 16px;
                width: 280px; max-height: calc(100vh - 32px);
                overflow-y: auto;
                background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
                color: #e0e0e0; padding: 18px;
                border-radius: 16px;
                border: 1px solid rgba(255, 215, 0, 0.25);
                z-index: 2147483647;
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 15px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.05);
                backdrop-filter: blur(20px);
                animation: dtFadeIn 0.2s ease-out;
            }
            #dragon-tracker-panel::-webkit-scrollbar { width: 4px; }
            #dragon-tracker-panel::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 2px; }
            @keyframes dtFadeIn { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
            #dragon-tracker-panel * { box-sizing: border-box; }
            .dt-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; gap: 8px; }
            .dt-title {
                font-weight: 700; font-size: 17px;
                background: linear-gradient(90deg, #ffd700, #ff8c00);
                -webkit-background-clip: text; background-clip: text;
                -webkit-text-fill-color: transparent; letter-spacing: 0.3px;
                white-space: nowrap;
            }
            .dt-status {
                font-size: 11px; color: #999; padding: 3px 8px;
                background: rgba(255,255,255,0.06); border-radius: 10px;
                max-width: 130px; overflow: hidden;
                text-overflow: ellipsis; white-space: nowrap;
            }
            .dt-row { display: flex; justify-content: space-between; align-items: baseline; padding: 5px 0; }
            .dt-label { color: #9a9a9a; font-size: 14px; }
            .dt-value { font-weight: 600; font-variant-numeric: tabular-nums; font-size: 15px; }
            .dt-dep { color: #4caf50; }
            .dt-with { color: #ff9800; }
            .dt-profit { color: #2196f3; font-size: 16px; }
            .dt-divider { height: 1px; background: rgba(255,255,255,0.08); margin: 10px 0; }
            .dt-btn {
                width: 100%; padding: 11px; margin-top: 12px;
                border: none; border-radius: 10px;
                background: linear-gradient(135deg, #4caf50, #2e7d32);
                color: #fff; font-weight: 700;
                cursor: pointer; font-size: 14px; font-family: inherit;
                letter-spacing: 0.4px;
                transition: filter 0.15s, transform 0.1s;
                display: flex; align-items: center; justify-content: center; gap: 8px;
            }
            .dt-btn:hover { filter: brightness(1.15); }
            .dt-btn:active { transform: scale(0.98); }
            .dt-btn.running { background: linear-gradient(135deg, #f44336, #b71c1c); }
            .dt-mem { margin-top: 14px; line-height: 0; }
            .dt-mem img { width: 100%; display: block; border-radius: 10px; }
            .dt-signature {
                margin-top: 8px;
                text-align: center;
                font-size: 10px;
                color: rgba(255,255,255,0.35);
                font-weight: 400;
                letter-spacing: 0.3px;
            }
            .dt-signature .dt-heart {
                color: #ff69b4;
                font-size: 11px;
            }
        `;
        document.head.appendChild(s);
    }

    // ========== ПАНЕЛЬ ==========
    function createPanel() {
        if (document.getElementById('dragon-tracker-panel')) return;
        injectStyles();

        const memUrl = chrome.runtime.getURL('mem.png');

        const panel = document.createElement('div');
        panel.id = 'dragon-tracker-panel';
        panel.innerHTML = `
            <div class="dt-header">
                <span class="dt-title">🐉 Dragon Tracker</span>
                <span class="dt-status" id="dt-status">готово</span>
            </div>
            <div class="dt-row"><span class="dt-label">Депозиты</span><span class="dt-value dt-dep" id="dt-dep">0 ₽</span></div>
            <div class="dt-row"><span class="dt-label">Выводы</span><span class="dt-value dt-with" id="dt-with">0 ₽</span></div>
            <div class="dt-divider"></div>
            <div class="dt-row"><span class="dt-label">Профит</span><span class="dt-value dt-profit" id="dt-profit">0 ₽</span></div>
            <button class="dt-btn" id="dt-auto-btn">▶ Старт</button>
            <div class="dt-mem"><img src="${memUrl}" alt="mem"></div>
            <div class="dt-signature">with <span class="dt-heart">♡</span> from @babyfaceplugg</div>
        `;
        document.body.appendChild(panel);
        console.log("🔥 Dragon Tracker: панель добавлена");

        document.getElementById('dt-auto-btn').addEventListener('click', () => {
            initAudio();
            if (isAutoRunning) stopAuto('вручную');
            else startAuto();
        });

        updateUI();
        loadDataAndScrape();
    }

    // ========== АВТО-РЕЖИМ ==========
    function startAuto() {
        if (!isHistoryPage()) return;
        isAutoRunning = true;
        const btn = document.getElementById('dt-auto-btn');
        if (btn) { btn.textContent = '⏹ Стоп'; btn.classList.add('running'); }
        setStatus('запуск...');
        console.log('🔥 Авто-режим запущен');
        runAutoPagination();
    }

    function stopAuto(reason) {
        isAutoRunning = false;
        const btn = document.getElementById('dt-auto-btn');
        if (btn) { btn.textContent = '▶ Старт'; btn.classList.remove('running'); }
        setStatus(reason ? `стоп: ${reason}` : 'стоп');
        console.log('🔥 Авто-режим остановлен:', reason || 'вручную');
        triggerEndEffect();
    }

    // Фейерверк/грусть в зависимости от профита
    function triggerEndEffect() {
        const now = Date.now();
        if (now - lastEffectTime < EFFECT_COOLDOWN) return;
        lastEffectTime = now;

        const profit = statData.withdrawals - statData.deposits;
        if (profit > 0) {
            launchConfetti();
            playFanfare();
        } else if (profit < 0) {
            launchSadEmojis();
            playSadSound();
        }
    }

    function runAutoPagination() {
        if (!isAutoRunning || !isHistoryPage()) { if (!isHistoryPage()) stopAuto('не история'); return; }
        if (hasNoData()) { stopAuto('нет данных'); return; }

        const nextBtn = getNextButton();
        if (!nextBtn) { stopAuto('кнопки нет'); return; }
        if (nextBtn.disabled) { stopAuto('конец'); return; }

        const oldPage = getCurrentPageNumber();
        const oldIds = getDataRowIds();

        setStatus(`стр. ${oldPage || '?'} →`);
        nextBtn.click();

        waitForChange(oldPage, oldIds, (result) => {
            if (!isAutoRunning) return;
            if (result === 'no-data') { stopAuto('нет данных'); return; }
            if (result === 'timeout') { stopAuto('таймаут'); return; }

            setTimeout(() => {
                if (!isAutoRunning) return;
                loadDataAndScrape();
                setStatus('считаю...');
                setTimeout(() => {
                    if (!isAutoRunning) return;
                    setStatus('готово');
                    setTimeout(runAutoPagination, DELAY_BETWEEN_CLICKS);
                }, DELAY_AFTER_RENDER);
            }, 100);
        });
    }

    function waitForChange(oldPage, oldIds, callback) {
        const start = Date.now();
        const oldIdsStr = JSON.stringify(oldIds);
        const hasPageNum = oldPage !== null && oldPage !== undefined && oldPage !== '';

        const check = () => {
            if (!isAutoRunning) return;
            if (Date.now() - start > PAGE_LOAD_TIMEOUT) { callback('timeout'); return; }
            if (hasNoData()) { callback('no-data'); return; }

            const newPage = getCurrentPageNumber();
            const newIdsStr = JSON.stringify(getDataRowIds());

            let loaded = false;
            if (hasPageNum && newPage && newPage !== oldPage) loaded = true;
            else if (!hasPageNum && newIdsStr !== oldIdsStr) loaded = true;

            if (loaded) callback('loaded');
            else setTimeout(check, 100);
        };
        setTimeout(check, 200);
    }

    // ========== СКРЕЙПИНГ ==========
    function loadDataAndScrape() {
        let newFound = false;

        document.querySelectorAll('.flex.row').forEach(row => {
            if (row.querySelector('.head')) return;
            const cells = row.querySelectorAll('.cell');
            if (cells.length < 6) return;

            const txId = cells[0].innerText.trim().replace(/\D/g, '');
            if (!txId || statData.processedIds.includes(txId)) return;

            const typeText = cells[1].innerText.trim();
            const amountText = cells[4].innerText.trim();
            const statusText = cells[5].innerText.trim();
            if (!statusText.includes('Выполнен')) return;

            const amount = parseInt(amountText.replace(/[^\d]/g, ''), 10);
            if (isNaN(amount)) return;

            if (typeText.includes('Вывод')) {
                statData.withdrawals += amount;
                console.log(`🔥 [Вывод] +${amount} (${txId})`);
            } else if (typeText.includes('Пополнение')) {
                statData.deposits += amount;
                console.log(`🔥 [Депозит] +${amount} (${txId})`);
            }
            statData.processedIds.push(txId);
            newFound = true;
        });

        if (newFound) updateUI();
    }

    function updateUI() {
        const fmt = n => n.toLocaleString('ru-RU');
        const d = document.getElementById('dt-dep');
        const w = document.getElementById('dt-with');
        const p = document.getElementById('dt-profit');
        if (d) d.textContent = fmt(statData.deposits) + ' ₽';
        if (w) w.textContent = fmt(statData.withdrawals) + ' ₽';
        const profit = statData.withdrawals - statData.deposits;
        if (p) {
            p.textContent = (profit >= 0 ? '+' : '') + fmt(profit) + ' ₽';
            p.style.color = profit >= 0 ? '#4caf50' : '#f44336';
        }
    }

    // ========== КОНФЕТТИ (профит) ==========
    function launchConfetti() {
        const canvas = document.createElement('canvas');
        canvas.id = 'dt-confetti';
        canvas.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:2147483646;';
        document.body.appendChild(canvas);

        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const colors = ['#ffd700', '#ff6b6b', '#4caf50', '#2196f3', '#ff9800', '#e91e63', '#9c27b0'];
        const particles = [];
        const bursts = [
            { x: canvas.width * 0.5, y: canvas.height * 0.5 },
            { x: canvas.width * 0.25, y: canvas.height * 0.35 },
            { x: canvas.width * 0.75, y: canvas.height * 0.35 },
        ];

        bursts.forEach(b => {
            for (let i = 0; i < 80; i++) {
                particles.push({
                    x: b.x + (Math.random() - 0.5) * 40,
                    y: b.y + (Math.random() - 0.5) * 40,
                    vx: (Math.random() - 0.5) * 14,
                    vy: (Math.random() - 1) * 14 - 2,
                    gravity: 0.35,
                    size: Math.random() * 8 + 4,
                    color: colors[Math.floor(Math.random() * colors.length)],
                    rotation: Math.random() * Math.PI * 2,
                    rotSpeed: (Math.random() - 0.5) * 0.4,
                });
            }
        });

        const DURATION = 3500;
        const startTime = Date.now();

        function animate() {
            const elapsed = Date.now() - startTime;
            if (elapsed > DURATION) { canvas.remove(); return; }

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const life = 1 - elapsed / DURATION;

            particles.forEach(p => {
                p.vy += p.gravity;
                p.x += p.vx;
                p.y += p.vy;
                p.rotation += p.rotSpeed;

                ctx.save();
                ctx.globalAlpha = Math.max(0, life);
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rotation);
                ctx.fillStyle = p.color;
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
                ctx.restore();
            });

            requestAnimationFrame(animate);
        }
        animate();
    }

    // ========== ГРУСТНЫЕ ЭМОДЗИ (убыток) ==========
    function launchSadEmojis() {
        const container = document.createElement('div');
        container.id = 'dt-sad-emojis';
        container.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:2147483646;overflow:hidden;';
        document.body.appendChild(container);

        const emojis = ['😢', '😞', '💔', '😭', '🥀', '😿', '📉', '💸'];
        const DURATION = 4500;
        const startTime = Date.now();
        const count = 35;
        const items = [];

        for (let i = 0; i < count; i++) {
            const el = document.createElement('div');
            el.textContent = emojis[Math.floor(Math.random() * emojis.length)];
            const fontSize = 24 + Math.random() * 24;
            el.style.cssText = `
                position: absolute;
                top: 0; left: 0;
                font-size: ${fontSize}px;
                opacity: 0;
                will-change: transform, opacity;
                user-select: none;
            `;
            container.appendChild(el);

            items.push({
                el,
                x: Math.random() * window.innerWidth,
                y: -50 - Math.random() * 100,
                vx: (Math.random() - 0.5) * 1.2,
                vy: 1 + Math.random() * 1.5,
                rot: Math.random() * 360,
                rotSpeed: (Math.random() - 0.5) * 2.5,
                delay: Math.random() * 1200,
            });
        }

        function animate() {
            const elapsed = Date.now() - startTime;
            if (elapsed > DURATION + 1000) { container.remove(); return; }

            items.forEach(it => {
                const localElapsed = elapsed - it.delay;
                if (localElapsed < 0) { it.el.style.opacity = '0'; return; }

                const totalLife = DURATION - it.delay;
                if (localElapsed > totalLife) { it.el.style.opacity = '0'; return; }

                it.vy += 0.02;
                it.x += it.vx;
                it.y += it.vy;
                it.rot += it.rotSpeed;

                const fadeIn = Math.min(1, localElapsed / 300);
                const fadeOut = Math.min(1, (totalLife - localElapsed) / 500);
                const opacity = Math.max(0, Math.min(fadeIn, fadeOut));

                it.el.style.opacity = opacity;
                it.el.style.transform = `translate(${it.x}px, ${it.y}px) rotate(${it.rot}deg)`;
            });

            requestAnimationFrame(animate);
        }
        animate();
    }

    // ========== OBSERVER ==========
    function setupObserver() {
        if (observer || !document.body) return;
        observer = new MutationObserver(() => {
            if (window._dtDebounce) clearTimeout(window._dtDebounce);
            window._dtDebounce = setTimeout(() => {
                if (isHistoryPage() && document.getElementById('dragon-tracker-panel') && !isAutoRunning) {
                    loadDataAndScrape();
                }
            }, SCRAPE_DEBOUNCE);
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    // ========== РОУТИНГ ==========
    function ensurePanel() {
        if (!isHistoryPage()) {
            const p = document.getElementById('dragon-tracker-panel');
            if (p) {
                isAutoRunning = false;
                p.remove();
                console.log('🔥 Панель скрыта (не /wallet/history)');
            }
            return;
        }
        if (!document.getElementById('dragon-tracker-panel')) createPanel();
    }

    const origPush = history.pushState;
    history.pushState = function () { origPush.apply(this, arguments); setTimeout(ensurePanel, 100); };
    const origReplace = history.replaceState;
    history.replaceState = function () { origReplace.apply(this, arguments); setTimeout(ensurePanel, 100); };
    window.addEventListener('popstate', () => setTimeout(ensurePanel, 100));
    setInterval(ensurePanel, 1000);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => { ensurePanel(); setupObserver(); });
    } else {
        ensurePanel();
        setupObserver();
    }
})();